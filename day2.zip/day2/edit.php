<?php
require_once('connectdb.php');
$id = (isset($_GET['id']))? $_GET['id']: NULL;
$message = "";

if(isset($_POST["update"])) {
    $id = $_POST["id"];
	$username = $_POST["username"];
    $email = $_POST["email"];
 

    if($username == '' OR $email == '') {
        $message = "All field is required";
    } 
	else {
         $sql ="UPDATE users SET username='$username', email='$email' WHERE id='$id'";

		if ($conn->query($sql) === TRUE) {
			$message = "Record upated successfully";
		} else {
			$message = "Error: " . $sql . "<br>" . $conn->error;
		}
    }
}


$sql = "SELECT * FROM users WHERE id=$id";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <link href="style.css" rel="stylesheet">
    <title>Day 3</title>
</head>
<body>
<div class="header">
	<h1>Computer Society of Filipinos International, Inc</h1>
</div>
<div class="content">
	<form action="edit.php" method="post">
    <h1 class="navy">Login Form</h1>
    <p class="grey">It is necessary to login in your account in order to sign in for a course.</p>
	<?php echo $message; ?>
	<div id="field">
	<?php 
	while($row = $result->fetch_assoc()){
	?>
		<fieldset id="newmember">
			<legend class="heading">
				<span class="grey">ARE YOU NEW?</span>
				<span class="navy">REGISTER</span>
			</legend>
			<input type="hidden" name="id" value="<?php echo $id; ?>"/>
			<input name="username" type="text" value="<?php echo $row["username"] ?>">
			<input name="email" type="email" value="<?php echo $row["email"] ?>">
			<input name="password" type="password" placeholder="Password">
			<input name="confirm" type="password" placeholder="Confirm Password">
			<input name="update" type="submit" value="Update">
			<a href="index.php">Back</a>
		</fieldset>
	<?php } 
	$conn->close();
	?>
    </div>
    </form>
</div>
</body>
</html>