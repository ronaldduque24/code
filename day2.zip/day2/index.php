<?php
require_once('connectdb.php');
$search = (isset($_POST["search"]))? $_POST["search"]: NULL;
$searchby = (isset($_POST["searchby"]))? $_POST["searchby"]: NULL; 
if(isset($_POST["searchbtn"])) {
	$sql ="SELECT * FROM users WHERE $searchby LIKE '%$search%'";
}else{
	$sql = "SELECT * FROM users";
}

$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<input name="search" type="text" value="<?php echo $search; ?>">
<select name="searchby">
	<option value="id" <?php echo ($searchby == 'id' )? 'selected="selected"':''; ?>>ID</option>
	<option value="username" <?php echo ($searchby == 'username' )? 'selected="selected"':''; ?>>Username</option>
	<option value="email" <?php echo ($searchby == 'email' )? 'selected="selected"':''; ?>>Email</option>
</select>
<input name="searchbtn" type="submit" value="Search">
</form>
<a href="add.php">Add</a>
<table>
<tr>
	<th>ID</th>
	<th>Username</th>
	<th>Email</th>
	<th>Action</th>
</tr>
<?php
if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) 
	 { 
?>	
	<tr>
		<td><?php echo $row["id"]; ?></td>
		<td><?php echo $row["username"] ?></td>
		<td><?php echo $row["email"]; ?></td>
		<td>
			<a href="edit.php?id=<?php echo $row["id"]; ?>">Edit</a>
			<a href="delete.php?id=<?php echo $row["id"]; ?>">Delete</a>
		</td>
	</tr>

<?php  
	}
} else {
     echo "0 results";
}

$conn->close();
?> 
</table> 

</body>
</html>