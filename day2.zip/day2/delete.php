<?php
require_once('connectdb.php');
if (isset($_GET['id']))
{
	// get id value
	$id = $_GET['id'];
	// delete the entry
	$sql = "DELETE FROM users WHERE id=$id";

	if ($conn->query($sql) === TRUE) {
		header("Location: select.php");
	} else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	}
	// redirect back to the view page

} else {
	header("Location: select.php");
}
$conn->close();
?>