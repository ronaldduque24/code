<?php
require_once('connectdb.php');
// include_once('connectdb.php');
// include('connectdb.php');
// require('connectdb.php');

if(isset($_POST["register"])) {
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $confirm = $_POST["confirm"];

    if($username == '' OR $email == '' OR $password == '') {
        $message = "All field is required";
    } elseif($password != $confirm){
		$message = "Password not match";
	}
	else {
        $sql = "INSERT INTO users (username, email, password)
		VALUES ('$username', '$email', '$password')";

		if ($conn->query($sql) === TRUE) {
			$message = "New record created successfully";
		} else {
			$message = "Error: " . $sql . "<br>" . $conn->error;
		}
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <link href="style.css" rel="stylesheet">
    <title>Day 3</title>
</head>
<body>
<div class="header">
	<h1>Computer Society of Filipinos International, Inc</h1>
</div>
<div class="content">
	<form action="index.php" method="post">
    <h1 class="navy">Login Form</h1>
    <p class="grey">It is necessary to login in your account in order to sign in for a course.</p>
 <?php echo $message; ?>
	<div id="field">
		<fieldset id="newmember">
			<legend class="heading">
				<span class="grey">ARE YOU NEW?</span>
				<span class="navy">REGISTER</span>
			</legend>
			<input name="username" type="text" placeholder="User name">
			<input name="email" type="email" placeholder="Email">
			<input name="password" type="password" placeholder="Password">
			<input name="confirm" type="password" placeholder="Confirm Password">
			<input name="register" type="submit" value="Register">
			<a href="index.php">Back</a>
		</fieldset>
    </div>
    </form>
</div>
</body>
</html>