<html>
   <body>
      <script language="javascript" type="text/javascript">
            alert("Hello World!")
      </script>
   </body>
</html>
