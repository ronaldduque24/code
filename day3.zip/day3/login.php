<?php
require_once('connectdb.php');
session_start();
$message = "";
if(isset($_POST["register"])) {
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $confirm = $_POST["confirm"];

    if($username == '' OR $email == '' OR $password == '') {
        $message = "All field is required";
    } elseif($password != $confirm){
		$message = "Password not match";
	}
	else {
		$hashpwd = md5($password);
        $sql = "INSERT INTO users (username, email, password)
		VALUES ('$username', '$email', '$hashpwd')";

		if ($conn->query($sql) === TRUE) {
			$message = "New record created successfully";
		} else {
			$message = "Error: " . $sql . "<br>" . $conn->error;
		}
    }
}

if(isset($_POST["login"])) {
	
	  $myusername = $conn->real_escape_string($_POST['loginusername']);
      $mypassword = md5($conn->real_escape_string($_POST['loginpassword'])); 
      
      $sql = "SELECT id FROM users WHERE username = '$myusername' and password = '$mypassword'";
	  $result = $conn->query($sql);
      $count = $result->num_rows;
      
      // If result matched $myusername and $mypassword, table row must be 1 row
      if($count == 1) {
         $_SESSION['username'] = $myusername;
		 $sql = "INSERT INTO history (userid, datelogin)
		VALUES ('$myusername', NOW())";
		$conn->query($sql);
		 // echo $_SESSION['username'];
		 // die();
         // $_SESSION['loggedin'] = true;
         header("location: index.php");
      }else {
         $message = "Your Userame or Password is invalid";
      }
}

$conn->close();
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <link href="style.css" rel="stylesheet">
    <title>Day 3</title>
</head>
<body>
<div class="header">
	<h1>Computer Society of Filipinos International, Inc</h1>
</div>
<div class="content">
	<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
    <h1 class="navy">Login Form</h1>
    <p class="grey">It is necessary to login in your account in order to sign in for a course.</p>
 <?php echo $message; ?>
	<div id="field">
		<fieldset id="newmember">
			<legend class="heading">
				<span class="grey">ARE YOU NEW?</span>
				<span class="navy">REGISTER</span>
			</legend>
			<input name="username" type="text" placeholder="User name">
			<input name="email" type="email" placeholder="Email">
			<input name="password" type="password" placeholder="Password">
			<input name="confirm" type="password" placeholder="Confirm Password">
			<input name="register" type="submit" value="Register">
		</fieldset>
		<fieldset id="student">
			<legend class="heading">ALREADY A STUDENT? LOGIN</legend>
			<input name="loginusername" type="text" placeholder="User name">
			<input name="loginpassword" type="password" placeholder="Password">
			<p id="remember"><input type="checkbox" name="check">Remember me?</p>
			<input name="login" type="submit" value="Login">
			<p id="forgot">Forgot Password?</p>
		</fieldset>
    </div>
    </form>
</div>
</body>
</html>