<?php
session_start();
if (!isset($_SESSION['username'])) {
	header("location: login.php");
}
include('connectdb.php');
$sql = "SELECT * FROM users";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
<script src="js/jquery-3.1.1.min.js"></script>
<script>
	$(document).ready(function() {
		// $( "#test" ).html( "Next Step..." )
		$( "#buttonid" ).on( "click", function( event ) {
		   $.ajax({
			  method: "POST",
			  url: "data.php",
			  data: { name: "Ron", location: "Khobar" }
			})
			  .done(function( name ) {
				alert( "My name is: " + name );
			});
		});
		
	});

</script>

</head>
<body>
<p>Welcome: <?php echo $_SESSION['username']; ?>   <a href="logout.php">Logout</a></p>
<p id="test">Ron</p>
<button id="buttonid">Change</button>
<table>
<tr>
	<th>ID</th>
	<th>Username</th>
	<th>Email</th>
	<th>Action</th>
</tr>
<?php
if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) 
	 { 
?>	
	<tr>
		<td><?php echo $row["id"]; ?></td>
		<td><?php echo $row["username"] ?></td>
		<td><?php echo $row["email"]; ?></td>
		<td>
			<a href="edit.php?id=<?php echo $row["id"]; ?>">Edit</a>
			<a href="delete.php?id=<?php echo $row["id"]; ?>">Delete</a>
		</td>
	</tr>

<?php  
	}
} else {
     echo "0 results";
}

$conn->close();
?> 
</table> 

</body>
</html>