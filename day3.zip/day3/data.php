<?php 
$name = $_POST["name"];
echo $name; 
?>